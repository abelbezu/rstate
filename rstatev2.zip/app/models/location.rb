class Location < ApplicationRecord
end
