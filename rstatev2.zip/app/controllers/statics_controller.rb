class StaticsController < ApplicationController
  def ie
  end
end

