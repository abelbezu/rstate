require 'test_helper'

class HouseDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
