class HouseDetail < ApplicationRecord
  belongs_to :listing
end
