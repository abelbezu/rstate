class Price < ApplicationRecord
  belongs_to :listing
end
