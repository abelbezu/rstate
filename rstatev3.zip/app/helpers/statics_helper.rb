module StaticsHelper
end
